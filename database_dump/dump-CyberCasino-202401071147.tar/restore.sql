--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "CyberCasino";
--
-- Name: CyberCasino; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "CyberCasino" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "CyberCasino" OWNER TO postgres;

\connect "CyberCasino"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: gamehistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gamehistory (
    user_email character varying NOT NULL,
    game_name character varying NOT NULL,
    amount numeric NOT NULL,
    id bigint NOT NULL,
    "time" timestamp with time zone NOT NULL
);


ALTER TABLE public.gamehistory OWNER TO postgres;

--
-- Name: transactionhistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactionhistory (
    user_email character varying NOT NULL,
    amount numeric NOT NULL,
    "time" timestamp with time zone NOT NULL,
    id bigint NOT NULL
);


ALTER TABLE public.transactionhistory OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    balance numeric NOT NULL,
    banned boolean NOT NULL,
    last_daily_spin date NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: gamehistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gamehistory (user_email, game_name, amount, id, "time") FROM stdin;
\.
COPY public.gamehistory (user_email, game_name, amount, id, "time") FROM '$$PATH$$/4796.dat';

--
-- Data for Name: transactionhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactionhistory (user_email, amount, "time", id) FROM stdin;
\.
COPY public.transactionhistory (user_email, amount, "time", id) FROM '$$PATH$$/4795.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (username, email, hashed_password, balance, banned, last_daily_spin) FROM stdin;
\.
COPY public.users (username, email, hashed_password, balance, banned, last_daily_spin) FROM '$$PATH$$/4794.dat';

--
-- Name: gamehistory gamehistory_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gamehistory
    ADD CONSTRAINT gamehistory_pk PRIMARY KEY (id);


--
-- Name: transactionhistory transactionhistory_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactionhistory
    ADD CONSTRAINT transactionhistory_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (email);


--
-- Name: users users_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_un UNIQUE (username);


--
-- Name: gamehistory gamehistory_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gamehistory
    ADD CONSTRAINT gamehistory_users_fk FOREIGN KEY (user_email) REFERENCES public.users(email);


--
-- Name: transactionhistory transactionhistory_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactionhistory
    ADD CONSTRAINT transactionhistory_users_fk FOREIGN KEY (user_email) REFERENCES public.users(email);


--
-- PostgreSQL database dump complete
--

